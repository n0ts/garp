/*
 * Soft:        Garp is a small utility to send gratuitous ARP.
 *              Can be used to script some remote ARP cache updates.
 *
 * Version:     $Id: main.c,v 0.1.1 2002/06/03 08:15:32 acassen Exp $
 *
 * Author:      Alexandre Cassen, <acassen@linux-vs.org>
 *
 *              This program is distributed in the hope that it will be useful,
 *              but WITHOUT ANY WARRANTY; without even the implied warranty of
 *              MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *              See the GNU General Public License for more details.
 *
 *              This program is free software; you can redistribute it and/or
 *              modify it under the terms of the GNU General Public License
 *              as published by the Free Software Foundation; either version
 *              2 of the License, or (at your option) any later version.
 */
#include "main.h"

/* Allocate & clean a buffer */
static void *xmalloc(unsigned long size)
{
  void *mem;
  if ((mem = malloc(size)))
    memset(mem, 0, size);
  return mem;
}

/* Dump a buffer (ASCII or Binary) */
static void print_buffer(int count, char *buff)
{
  int i,j,c;
  int printnext=1;

  if(count) {
    if(count%16)
      c=count+(16-count%16);
    else c=count;
  } else
    c=count;

  for(i=0;i<c;i++) {
    if(printnext) {
      printnext--;
      printf("%.4x ",i&0xffff);
    }
    if(i<count)
      printf("%3.2x",buff[i]&0xff);
    else
      printf("   ");
    if(!((i+1)%8)) {
      if((i+1)%16)
        printf(" -");
      else {
        printf("   ");
        for(j=i-15;j<=i;j++)
          if(j<count) {
            if( (buff[j]&0xff) >= 0x20 && (buff[j]&0xff)<=0x7e)
              printf("%c",buff[j]&0xff);
            else printf(".");
          } else printf(" ");
        printf("\n"); printnext=1;
      }
    }
  }
}

/* ip address formating output */
char *ip_ntoa(uint32_t ip)
{
  static char buf[20];
  unsigned char *bytep;

  bytep = (unsigned char *) &(ip);
  sprintf(buf, "%d.%d.%d.%d", bytep[0], bytep[1], bytep[2], bytep[3]);
  return buf;
}

/* Dump procedure */
static void dump_cfg(void)
{
  printf("Using MAC addr   : %.2X:%.2X:%.2X:%.2X:%.2X:%.2X\n"
         , garp_arg->hwaddr[0]&0xff, garp_arg->hwaddr[1]&0xff
         , garp_arg->hwaddr[2]&0xff, garp_arg->hwaddr[3]&0xff
         , garp_arg->hwaddr[4]&0xff, garp_arg->hwaddr[5]&0xff);
  printf("Using NIC        : %s\n", garp_arg->interface);
  if (garp_arg->addr)
    printf("Using IP address : %s\n\n", ip_ntoa(garp_arg->addr));
  if (garp_arg->file)
    printf("Using file IP address : %s\n\n", garp_arg->file);
}

/* fetching interface hwaddress */
static int get_hwaddr(void)
{
  struct ifreq ifr;
  int fd = socket(AF_INET, SOCK_DGRAM, 0);
  int ret;

  if (fd < 0)
    return (-1);
  strncpy(ifr.ifr_name, garp_arg->interface, sizeof(ifr.ifr_name));
  ret = ioctl(fd, SIOCGIFHWADDR, (char *)&ifr);
  memcpy(garp_arg->hwaddr, ifr.ifr_hwaddr.sa_data, 6);

  close(fd);
  return ret;
}

/* send VRRP packet */
static int send_packet(char *buffer, int buflen)
{
  struct sockaddr from;
  int len;
  int fd = socket(PF_PACKET, SOCK_PACKET, 0x300); /* 0x300 is magic */

  if (fd < 0) {
    fprintf(stderr, "socket creation...\n");
    return -1;
  }

  /* build the address */
  memset(&from, 0, sizeof(from));
  strcpy(from.sa_data, garp_arg->interface);

  if (garp_arg->verbose) {
    printf("Packet sent :\n");
    print_buffer(buflen, buffer);
  }

  /* send the data */
  len = sendto(fd, buffer, buflen, 0, &from, sizeof(from));

  close(fd);
  return len;
}

/* send a gratuitous ARP packet */
static int send_gratuitous_arp(uint32_t addr)
{
  char buf[sizeof(m_arphdr) + ETHER_HDR_LEN];
  char buflen			= sizeof(m_arphdr) + ETHER_HDR_LEN;
  struct ether_header *eth	= (struct ether_header *)buf;
  m_arphdr *arph		= (m_arphdr *) (buf + ETHER_HDR_LEN);
  char *hwaddr			= garp_arg->hwaddr;
  int hwlen			= ETH_ALEN;

  /* hardcoded for ethernet */
  memset(eth->ether_dhost, 0xFF, ETH_ALEN);
  memcpy(eth->ether_shost, hwaddr, hwlen);
  eth->ether_type = htons(ETHERTYPE_ARP);

  /* build the arp payload */
  memset(arph, 0, sizeof(*arph));
  arph->ar_hrd = htons(ARPHRD_ETHER);
  arph->ar_pro = htons(ETHERTYPE_IP);
  arph->ar_hln = 6;
  arph->ar_pln = 4;
  arph->ar_op  = htons(ARPOP_REQUEST);
  memcpy(arph->__ar_sha, hwaddr, hwlen);
  memcpy(arph->__ar_sip, &addr, sizeof(addr));
  memcpy(arph->__ar_tip, &addr, sizeof(addr));

  return send_packet(buf, buflen);
}

/* Usage function */
static void usage(const char *prog)
{
  fprintf(stderr, VERSION_STRING);
  fprintf(stderr, 
    "Usage:\n"
    "  %s -i eth0 -a 192.168.1.1 -n 5\n"
    "  %s -h\n"
    "  %s -v\n\n",
    prog, prog, prog);
  fprintf(stderr, 
    "Commands:\n"
    "Either long or short options are allowed.\n"
    "  %s --interface       -i       Send gratuitous arp using the interface.\n"
    "  %s --use-file        -f       Use the specified file containing set of IP.\n"
    "  %s --ipaddress       -a       Use the specified IP address.\n"
    "  %s --arp-num         -n       Send specified number of gratuitous ARP.\n"
    "  %s --verbose         -V       Use verbose output infos.\n"
    "  %s --help            -h       Display this short inlined help screen.\n"
    "  %s --version         -v       Display the version number\n",
    prog, prog, prog, prog, prog, prog, prog);
}

/* Command line parser */
static int parse_cmdline(int argc, char **argv)
{
  poptContext context;
  char *optarg = NULL;
  int c;

  struct poptOption options_table[] = {
    {"version",         'v', POPT_ARG_NONE,      NULL, 'v'},
    {"help",            'h', POPT_ARG_NONE,      NULL, 'h'},
    {"verbose",         'V', POPT_ARG_NONE,      NULL, 'V'},
    {"use-file",        'f', POPT_ARG_STRING, &optarg, 'f'},
    {"ipaddress",       'a', POPT_ARG_STRING, &optarg, 'a'},
    {"interface",       'i', POPT_ARG_STRING, &optarg, 'i'},
    {"arp-num",         'n', POPT_ARG_STRING, &optarg, 'n'},
    {NULL, 0, 0, NULL, 0}
  };

  context = poptGetContext(PROG, argc, (const char **)argv
                                     , options_table, 0);
  if ((c = poptGetNextOpt(context)) < 0) {
    usage(argv[0]);
    return CMD_LINE_ERROR;
  }

  /* Default initialization */
  garp_arg->num = 1;

  /* The first option car */
  switch (c) {
    case 'v':
      fprintf(stderr, VERSION_STRING);
      break;
    case 'h':
      usage(argv[0]);
      break;
    case 'V':
      garp_arg->verbose = 1;
      break;
    case 'f':
      garp_arg->file = optarg;
      break;
    case 'i':
      garp_arg->interface = optarg;
      break;
    default:
      usage(argv[0]);
      return CMD_LINE_ERROR;
  }

  /* the others */
  while ((c = poptGetNextOpt(context)) >= 0) {
    switch (c) {
      case 'V':
        garp_arg->verbose = 1;
        break;
      case 'f':
        garp_arg->file = optarg;
        break;
      case 'i':
        garp_arg->interface = optarg;
        break;
      case 'a':
        garp_arg->addr = inet_addr(optarg);
        break;
      case 'n':
        garp_arg->num = atoi(optarg);
        break;
      default:
        usage(argv[0]);
        return CMD_LINE_ERROR;
    }
  }

  /* check unexpected arguments */
  if ((optarg = (char *)poptGetArg(context))) {
    fprintf(stderr, "unexpected argument %s", optarg);
    return CMD_LINE_ERROR;
  }

  /* free the allocated context */
  poptFreeContext(context);
  
  return CMD_LINE_SUCCESS;
}

/* Open the file and send garp on each line IP addresses */
static void broadcast_arp_file(void)
{
  int i;
  char *string = (char *)xmalloc(BUFSIZE);

  garp_arg->stream = fopen(garp_arg->file, "r");
  if (!garp_arg->stream) {
    fprintf(stderr, "Cann t open file : %s\n", garp_arg->file);
    return;
  }

  fscanf(garp_arg->stream, "%s", string);
  while (!feof(garp_arg->stream)) {
    for (i=0; i < garp_arg->num; i++)
      send_gratuitous_arp(inet_addr(string));
    fscanf(garp_arg->stream, "%s", string);
  }

  fclose(garp_arg->stream);
  free(string);
}

static void broadcast_arp(void)
{
  int i;

  if (garp_arg->addr) {
    for (i=0; i < garp_arg->num; i++)
      send_gratuitous_arp(garp_arg->addr);
  } else if (garp_arg->file)
    broadcast_arp_file();
}

/* Minimum config is Interface & ipaddress */
static int check_min_cfg(void)
{
  if (garp_arg->addr && garp_arg->file) {
    fprintf(stderr, "Cannot use both address & file !!!\n");
    return 0;
  }
  if (!garp_arg->interface)
    return 0;
  return 1;
}

int main(int argc, char **argv)
{
  /* Allocate the room */
  garp_arg = (garp *)xmalloc(sizeof(garp));

  /* Command line parser */
  if (!parse_cmdline(argc, argv))
    goto end;
  if (!check_min_cfg())
    goto end;

  /* Complete initialization */
  get_hwaddr();

  /* Dump if verbose active */
  if (garp_arg->verbose)
    dump_cfg();

  /* Sending the Gratuitous ARP probe */
  broadcast_arp();

end:
  /* free the room */
  free(garp_arg);
  return 1;
}
