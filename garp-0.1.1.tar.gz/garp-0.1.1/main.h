/*
 * Soft:        Garp is a small utility to send gratuitous ARP.
 *              Can be used to script some remote ARP cache updates.
 *
 * Version:     $Id: main.h,v 0.1.1 2002/06/03 08:15:32 acassen Exp $
 *
 * Author:      Alexandre Cassen, <acassen@linux-vs.org>
 *
 *              This program is distributed in the hope that it will be useful,
 *              but WITHOUT ANY WARRANTY; without even the implied warranty of
 *              MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *              See the GNU General Public License for more details.
 *
 *              This program is free software; you can redistribute it and/or
 *              modify it under the terms of the GNU General Public License
 *              as published by the Free Software Foundation; either version
 *              2 of the License, or (at your option) any later version.
 */

#ifndef _MAIN_H
#define _MAIN_H

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <net/ethernet.h>
#include <netinet/ip.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <time.h>
#include <sys/errno.h>
#include <net/if.h>
#include <net/if_arp.h>
#include <net/ethernet.h>
#include <sys/ioctl.h>
#include <ctype.h>
#include <string.h>
#include <popt.h>

/* Build version */
#define PROG   "garp"
#define AUTHOR "Alexandre Cassen"

#define VERSION_CODE 0x000100
#define DATE_CODE    0x1F0502

#define GARP_VERSION(version)     \
        (version >> 16) & 0xFF,   \
        (version >> 8) & 0xFF,    \
        version & 0xFF

#define VERSION_STRING PROG" v%d.%d.%d (%.2d/%.2d, 20%.2d), Copyright (C) %s\n", \
                GARP_VERSION(VERSION_CODE), \
                GARP_VERSION(DATE_CODE),    \
                AUTHOR

/* GARP definition structure */
typedef struct {
  char		*interface;	/* NIC to use */
  char		hwaddr[6];	/* MAC addr of the used NIC */
  uint32_t	addr;		/* IP address to use */
  int		num;		/* Number of gratuitous arp sent */
  int		verbose;	/* Verbose mode ? */
  char		*file;		/* File containing a set of IP address */
  FILE		*stream;	/* file stream handler */
} garp;

/* ARP packet structure definition */
typedef struct _m_arphdr {
  unsigned short int ar_hrd;          /* Format of hardware address.  */
  unsigned short int ar_pro;          /* Format of protocol address.  */
  unsigned char ar_hln;               /* Length of hardware address.  */
  unsigned char ar_pln;               /* Length of protocol address.  */
  unsigned short int ar_op;           /* ARP opcode (command).  */

  /* Ethernet looks like this : This bit is variable sized however...  */
  unsigned char __ar_sha[ETH_ALEN];   /* Sender hardware address.  */
  unsigned char __ar_sip[4];          /* Sender IP address.  */
  unsigned char __ar_tha[ETH_ALEN];   /* Target hardware address.  */
  unsigned char __ar_tip[4];          /* Target IP address.  */
} m_arphdr;

/* Data buffer length description */
#define BUFSIZE             64

/* Global declarations */
garp *garp_arg;

/* Command line error handling */
#define CMD_LINE_ERROR   0
#define CMD_LINE_SUCCESS 1

#endif
